//
//  ViewController.swift
//  VIP
//
//  Created by Mac on 5/22/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

