//
//  TaskListRouter.swift
//  VIP
//
//  Created by Mac on 5/22/23.
//

import UIKit

protocol TaskListRoutingLogic {
    func routeToAddTask()
    func routeToEditTask(task: Task)
}

protocol TaskListDataPassing {
    var dataStore: TaskListDataStore? { get }
}

class TaskListRouter: NSObject, TaskListRoutingLogic, TaskListDataPassing {
    
    weak var viewController: TaskListViewController?
    var dataStore: TaskListDataStore?

    // MARK: TaskListRoutingLogic

    func routeToAddTask() {
        guard let viewController = viewController else { return }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "AddTaskViewController") as! AddTaskViewController
        var destinationDS: AddTaskDataStore = destinationVC.router.dataStore! as! AddTaskDataStore
//        var destinationDS = destinationVC.router!.dataStore!

        passDataToAddTask(source: dataStore!, destination: &destinationDS)
        viewController.show(destinationVC, sender: nil)
    }

    func routeToEditTask(task: Task) {
        guard let viewController = viewController else { return }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "EditTaskViewController") as! EditTaskViewController
        
        var destinationDS: EditTaskDataStore = destinationVC.router.dataStore! as! EditTaskDataStore

//        var destinationDS = destinationVC.router!.dataStore!
        passDataToEditTask(task: task, source: dataStore!, destination: &destinationDS)
        viewController.show(destinationVC, sender: nil)
    }
    
    // MARK: Navigation
    
    func passDataToAddTask(source: TaskListDataStore, destination: inout AddTaskDataStore) {
        
        destination.taskListWorker = source.taskListWorker
        destination.taskListInteractor = source.taskListInteractor
    }
    
    func passDataToEditTask(task: Task, source: TaskListDataStore, destination: inout EditTaskDataStore) {
        destination.taskListWorker = source.taskListWorker
        destination.taskListInteractor = source.taskListInteractor
        destination.task = task
    }
}

//class TaskListRouter: NSObject {
//
//}
