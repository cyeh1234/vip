//
//  Task.swift
//  VIP
//
//  Created by Mac on 5/22/23.
//

import Foundation

struct Task {
    var id: Int
    var title: String
    var completed: Bool
}
